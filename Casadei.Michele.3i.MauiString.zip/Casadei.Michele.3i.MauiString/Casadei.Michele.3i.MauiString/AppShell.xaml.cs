﻿namespace Casadei.Michele._3i.MauiString;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
